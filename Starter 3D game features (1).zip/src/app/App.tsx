import { useEffect, useRef, useState, useCallback } from "react";
import * as THREE from "three";

// ─── Constants ────────────────────────────────────────────────────────────────
const TEAM_ALPHA = "alpha";
const TEAM_BRAVO = "bravo";
type Team = typeof TEAM_ALPHA | typeof TEAM_BRAVO;

const PLAYER_SPEED = 8;
const PLAYER_HEIGHT = 1.7;
const GRAVITY = 20;
const JUMP_FORCE = 8;
const SHOOT_COOLDOWN = 0.15;
const BOT_COUNT = 7; // per team (7v7 balanced for performance)
const ROUND_SCORE_LIMIT = 100;
const RESPAWN_TIME = 4;
const ARENA_SIZE = 80;
const BULLET_SPEED = 60;
const BOT_SPEED = 4;
const BOT_SIGHT_RANGE = 30;
const BOT_SHOOT_RANGE = 25;

// ─── Types ────────────────────────────────────────────────────────────────────
interface BotState {
  mesh: THREE.Group;
  team: Team;
  hp: number;
  velocity: THREE.Vector3;
  dead: boolean;
  respawnTimer: number;
  shootCooldown: number;
  target: THREE.Vector3 | null;
  wanderTarget: THREE.Vector3;
  wanderTimer: number;
  id: number;
}

interface Bullet {
  mesh: THREE.Mesh;
  velocity: THREE.Vector3;
  team: Team;
  fromBot: boolean;
  life: number;
}

interface KillFeed {
  id: number;
  killer: string;
  victim: string;
  team: Team;
  time: number;
}

// ─── Arena Builder ─────────────────────────────────────────────────────────────
function buildArena(scene: THREE.Scene): THREE.Mesh[] {
  const collidables: THREE.Mesh[] = [];

  const matGround = new THREE.MeshLambertMaterial({ color: 0x2a3520 });
  const matConcrete = new THREE.MeshLambertMaterial({ color: 0x4a4a4a });
  const matAlpha = new THREE.MeshLambertMaterial({ color: 0x1a3a6e });
  const matBravo = new THREE.MeshLambertMaterial({ color: 0x6e1a1a });
  const matMetal = new THREE.MeshLambertMaterial({ color: 0x555566 });
  const matRoof = new THREE.MeshLambertMaterial({ color: 0x333333 });
  const matDark = new THREE.MeshLambertMaterial({ color: 0x222222 });

  // Ground
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(ARENA_SIZE, ARENA_SIZE), matGround);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  scene.add(ground);

  // Boundary walls
  const wallH = 6;
  const wallConfigs = [
    { pos: [0, wallH / 2, -ARENA_SIZE / 2], size: [ARENA_SIZE, wallH, 0.8] },
    { pos: [0, wallH / 2, ARENA_SIZE / 2], size: [ARENA_SIZE, wallH, 0.8] },
    { pos: [-ARENA_SIZE / 2, wallH / 2, 0], size: [0.8, wallH, ARENA_SIZE] },
    { pos: [ARENA_SIZE / 2, wallH / 2, 0], size: [0.8, wallH, ARENA_SIZE] },
  ];
  wallConfigs.forEach(({ pos, size }) => {
    const w = new THREE.Mesh(new THREE.BoxGeometry(...(size as [number, number, number])), matConcrete);
    w.position.set(...(pos as [number, number, number]));
    w.castShadow = true;
    scene.add(w);
    collidables.push(w);
  });

  // Alpha base (blue, -Z side)
  const alphaBase = buildBase(scene, collidables, new THREE.Vector3(0, 0, -32), matAlpha, matConcrete);
  void alphaBase;

  // Bravo base (red, +Z side)
  const bravoBase = buildBase(scene, collidables, new THREE.Vector3(0, 0, 32), matBravo, matConcrete);
  void bravoBase;

  // Central multi-floor building
  buildCentralBuilding(scene, collidables, matRoof, matMetal, matDark);

  // Sniper towers
  buildSniperTower(scene, collidables, new THREE.Vector3(-28, 0, -18), matConcrete, matMetal);
  buildSniperTower(scene, collidables, new THREE.Vector3(28, 0, 18), matConcrete, matMetal);
  buildSniperTower(scene, collidables, new THREE.Vector3(-28, 0, 18), matConcrete, matMetal);
  buildSniperTower(scene, collidables, new THREE.Vector3(28, 0, -18), matConcrete, matMetal);

  // Cover rocks / crates scattered around mid
  const cratePositions: [number, number, number, number, number, number][] = [
    [-8, 0.6, -8, 2, 1.2, 2],
    [8, 0.6, -8, 2, 1.2, 2],
    [-8, 0.6, 8, 2, 1.2, 2],
    [8, 0.6, 8, 2, 1.2, 2],
    [-14, 0.5, 0, 3, 1, 1.5],
    [14, 0.5, 0, 3, 1, 1.5],
    [0, 0.5, -14, 1.5, 1, 3],
    [0, 0.5, 14, 1.5, 1, 3],
    [-20, 0.5, -5, 2, 1, 2],
    [20, 0.5, 5, 2, 1, 2],
    [-5, 0.5, 20, 2, 1, 2],
    [5, 0.5, -20, 2, 1, 2],
  ];
  cratePositions.forEach(([x, y, z, w, h, d]) => {
    const mat = new THREE.MeshLambertMaterial({ color: 0x5c4a2a });
    const crate = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    crate.position.set(x, y, z);
    crate.castShadow = true;
    scene.add(crate);
    collidables.push(crate);
  });

  return collidables;
}

function buildBase(
  scene: THREE.Scene,
  collidables: THREE.Mesh[],
  center: THREE.Vector3,
  mat: THREE.Material,
  matConc: THREE.Material
) {
  const bw = 22, bd = 14, bh = 3;
  // Back wall
  const backWall = new THREE.Mesh(new THREE.BoxGeometry(bw, bh, 1), mat);
  backWall.position.set(center.x, bh / 2, center.z + (center.z < 0 ? -bd / 2 : bd / 2));
  scene.add(backWall);
  collidables.push(backWall);

  // Side walls
  [-1, 1].forEach(side => {
    const sw = new THREE.Mesh(new THREE.BoxGeometry(1, bh, bd), matConc);
    sw.position.set(center.x + side * (bw / 2), bh / 2, center.z);
    scene.add(sw);
    collidables.push(sw);
  });

  // Floor platform (raised slightly)
  const floor = new THREE.Mesh(new THREE.BoxGeometry(bw, 0.3, bd), matConc);
  floor.position.set(center.x, 0.15, center.z);
  scene.add(floor);

  // Front opening wall with gaps (doorway)
  const frontL = new THREE.Mesh(new THREE.BoxGeometry(7, bh, 1), matConc);
  frontL.position.set(center.x - 7.5, bh / 2, center.z + (center.z < 0 ? bd / 2 : -bd / 2));
  scene.add(frontL);
  collidables.push(frontL);

  const frontR = new THREE.Mesh(new THREE.BoxGeometry(7, bh, 1), matConc);
  frontR.position.set(center.x + 7.5, bh / 2, center.z + (center.z < 0 ? bd / 2 : -bd / 2));
  scene.add(frontR);
  collidables.push(frontR);

  // Door lintel above gap
  const lintel = new THREE.Mesh(new THREE.BoxGeometry(8, 1, 1), matConc);
  lintel.position.set(center.x, bh - 0.5, center.z + (center.z < 0 ? bd / 2 : -bd / 2));
  scene.add(lintel);
  collidables.push(lintel);

  return { backWall, floor };
}

function buildCentralBuilding(
  scene: THREE.Scene,
  collidables: THREE.Mesh[],
  matRoof: THREE.Material,
  matMetal: THREE.Material,
  matDark: THREE.Material
) {
  const bw = 16, bh1 = 4, bh2 = 4, bd = 12;

  // Ground floor walls (with openings simulated by separate pieces)
  const wallPieces: { pos: [number, number, number]; size: [number, number, number] }[] = [
    // North wall with door gap
    { pos: [-6, bh1 / 2, -bd / 2], size: [4, bh1, 0.6] },
    { pos: [6, bh1 / 2, -bd / 2], size: [4, bh1, 0.6] },
    { pos: [0, bh1 - 0.5, -bd / 2], size: [8, 1, 0.6] }, // lintel
    // South wall with door gap
    { pos: [-6, bh1 / 2, bd / 2], size: [4, bh1, 0.6] },
    { pos: [6, bh1 / 2, bd / 2], size: [4, bh1, 0.6] },
    { pos: [0, bh1 - 0.5, bd / 2], size: [8, 1, 0.6] },
    // East wall with window
    { pos: [bw / 2, 0.5, -3], size: [0.6, 1, 6] }, // lower solid
    { pos: [bw / 2, bh1 - 0.5, 0], size: [0.6, 1, bd] }, // upper
    { pos: [bw / 2, bh1 / 2, -3], size: [0.6, bh1 - 1, 0.6] }, // window pillar
    { pos: [bw / 2, bh1 / 2, 3], size: [0.6, bh1 - 1, 0.6] },
    // West wall with window
    { pos: [-bw / 2, 0.5, -3], size: [0.6, 1, 6] },
    { pos: [-bw / 2, bh1 - 0.5, 0], size: [0.6, 1, bd] },
    { pos: [-bw / 2, bh1 / 2, -3], size: [0.6, bh1 - 1, 0.6] },
    { pos: [-bw / 2, bh1 / 2, 3], size: [0.6, bh1 - 1, 0.6] },
  ];

  wallPieces.forEach(({ pos, size }) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(...size), matMetal);
    m.position.set(...pos);
    m.castShadow = true;
    scene.add(m);
    collidables.push(m);
  });

  // Second floor platform / ceiling of ground floor
  const floor2 = new THREE.Mesh(new THREE.BoxGeometry(bw, 0.4, bd), matDark);
  floor2.position.set(0, bh1, 0);
  scene.add(floor2);
  collidables.push(floor2);

  // Staircase up to 2nd floor (exterior, north side)
  for (let i = 0; i < 5; i++) {
    const step = new THREE.Mesh(new THREE.BoxGeometry(3, 0.4, 1), matMetal);
    step.position.set(-bw / 2 - 1.5, 0.4 + i * 0.8, -bd / 2 + 0.5 + i * 1.2);
    scene.add(step);
    collidables.push(step);
  }
  // Stair landing
  const landing = new THREE.Mesh(new THREE.BoxGeometry(4, 0.4, 4), matMetal);
  landing.position.set(-bw / 2 - 2, bh1, -bd / 2 + 7.5);
  scene.add(landing);
  collidables.push(landing);

  // 2nd floor walls (shorter, with more windows)
  const wall2Pieces: { pos: [number, number, number]; size: [number, number, number] }[] = [
    { pos: [0, bh1 + bh2 / 2, -bd / 2], size: [bw, bh2, 0.6] },
    { pos: [0, bh1 + bh2 / 2, bd / 2], size: [bw, bh2, 0.6] },
    { pos: [bw / 2, bh1 + bh2 / 2, 0], size: [0.6, bh2, bd] },
    { pos: [-bw / 2, bh1 + bh2 / 2, 0], size: [0.6, bh2, bd] },
  ];
  wall2Pieces.forEach(({ pos, size }) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(...size), matMetal);
    m.position.set(...pos);
    scene.add(m);
    collidables.push(m);
  });

  // Roof
  const roof = new THREE.Mesh(new THREE.BoxGeometry(bw + 1, 0.5, bd + 1), matRoof);
  roof.position.set(0, bh1 + bh2 + 0.25, 0);
  scene.add(roof);
  collidables.push(roof);
}

function buildSniperTower(
  scene: THREE.Scene,
  collidables: THREE.Mesh[],
  pos: THREE.Vector3,
  matConc: THREE.Material,
  matMetal: THREE.Material
) {
  // Base
  const base = new THREE.Mesh(new THREE.CylinderGeometry(2, 2.5, 1, 8), matConc);
  base.position.set(pos.x, 0.5, pos.z);
  scene.add(base);
  collidables.push(base);

  // Shaft
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(1, 1.2, 8, 8), matConc);
  shaft.position.set(pos.x, 5, pos.z);
  scene.add(shaft);
  collidables.push(shaft);

  // Ladder rungs (visual only)
  for (let i = 0; i < 8; i++) {
    const rung = new THREE.Mesh(new THREE.BoxGeometry(1, 0.08, 0.08), matMetal);
    rung.position.set(pos.x, 1.5 + i, pos.z + 1);
    scene.add(rung);
  }

  // Platform
  const platform = new THREE.Mesh(new THREE.CylinderGeometry(3, 2.5, 0.4, 8), matMetal);
  platform.position.set(pos.x, 9.2, pos.z);
  scene.add(platform);
  collidables.push(platform);

  // Railing
  for (let i = 0; i < 8; i++) {
    const angle = (i / 8) * Math.PI * 2;
    const rail = new THREE.Mesh(new THREE.BoxGeometry(0.1, 1, 0.1), matMetal);
    rail.position.set(pos.x + Math.cos(angle) * 2.8, 9.9, pos.z + Math.sin(angle) * 2.8);
    scene.add(rail);
  }
  const topRail = new THREE.Mesh(new THREE.TorusGeometry(2.8, 0.07, 6, 16), matMetal);
  topRail.position.set(pos.x, 10.4, pos.z);
  topRail.rotation.x = Math.PI / 2;
  scene.add(topRail);
}

// ─── Bot Builder ───────────────────────────────────────────────────────────────
function createBot(scene: THREE.Scene, team: Team, id: number): BotState {
  const group = new THREE.Group();
  const color = team === TEAM_ALPHA ? 0x2255cc : 0xcc2222;
  const mat = new THREE.MeshLambertMaterial({ color });
  const matDark = new THREE.MeshLambertMaterial({ color: 0x111111 });

  // Body
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.9, 0.35), mat);
  body.position.y = 0.95;
  group.add(body);

  // Head
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.45, 0.45), mat);
  head.position.y = 1.6;
  group.add(head);

  // Arms
  [-0.42, 0.42].forEach(x => {
    const arm = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.7, 0.2), mat);
    arm.position.set(x, 0.95, 0);
    group.add(arm);
  });

  // Legs
  [-0.18, 0.18].forEach(x => {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.6, 0.25), matDark);
    leg.position.set(x, 0.3, 0);
    group.add(leg);
  });

  // Gun
  const gun = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 0.5), matDark);
  gun.position.set(0.35, 1.15, -0.3);
  group.add(gun);

  scene.add(group);

  const spawnPos = getBotSpawnPos(team);
  group.position.copy(spawnPos);

  return {
    mesh: group,
    team,
    hp: 100,
    velocity: new THREE.Vector3(),
    dead: false,
    respawnTimer: 0,
    shootCooldown: Math.random() * 2,
    target: null,
    wanderTarget: spawnPos.clone(),
    wanderTimer: 0,
    id,
  };
}

function getBotSpawnPos(team: Team): THREE.Vector3 {
  const z = team === TEAM_ALPHA ? -32 : 32;
  return new THREE.Vector3((Math.random() - 0.5) * 14, PLAYER_HEIGHT, z + (Math.random() - 0.5) * 6);
}

// ─── Lighting ─────────────────────────────────────────────────────────────────
function setupLighting(scene: THREE.Scene) {
  // Soft sky ambient
  const ambient = new THREE.AmbientLight(0x6688aa, 0.6);
  scene.add(ambient);

  // Hemisphere sky/ground
  const hemi = new THREE.HemisphereLight(0x88aacc, 0x334422, 0.7);
  scene.add(hemi);

  // Main sun — warm golden angle
  const sun = new THREE.DirectionalLight(0xffe0a0, 2.0);
  sun.position.set(40, 60, 30);
  sun.castShadow = true;
  sun.shadow.mapSize.width = 2048;
  sun.shadow.mapSize.height = 2048;
  sun.shadow.camera.far = 200;
  sun.shadow.camera.left = -70;
  sun.shadow.camera.right = 70;
  sun.shadow.camera.top = 70;
  sun.shadow.camera.bottom = -70;
  sun.shadow.bias = -0.001;
  scene.add(sun);

  // Soft fill from opposite side (cool blue)
  const fill = new THREE.DirectionalLight(0x88bbff, 0.5);
  fill.position.set(-30, 20, -20);
  scene.add(fill);

  // Central building highlight
  const centralSpot = new THREE.SpotLight(0xffffff, 3, 40, Math.PI / 5, 0.4);
  centralSpot.position.set(0, 25, 0);
  centralSpot.target.position.set(0, 0, 0);
  scene.add(centralSpot);
  scene.add(centralSpot.target);

  // Alpha base glow — blue
  const alphaLight = new THREE.PointLight(0x2266ff, 4, 30);
  alphaLight.position.set(0, 5, -32);
  scene.add(alphaLight);

  // Bravo base glow — red
  const bravoLight = new THREE.PointLight(0xff3311, 4, 30);
  bravoLight.position.set(0, 5, 32);
  scene.add(bravoLight);

  // Mid-field accent lights on towers
  const towerColors = [0xffaa22, 0xffaa22, 0x22aaff, 0x22aaff];
  const towerPositions: [number, number, number][] = [[-28, 10, -18], [28, 10, 18], [-28, 10, 18], [28, 10, -18]];
  towerPositions.forEach((pos, i) => {
    const light = new THREE.PointLight(towerColors[i], 2, 20);
    light.position.set(...pos);
    scene.add(light);
  });
}

// ─── AABB Collision ────────────────────────────────────────────────────────────
function checkAABB(pos: THREE.Vector3, collidables: THREE.Mesh[]): THREE.Vector3 {
  const radius = 0.35;
  const height = PLAYER_HEIGHT;
  const playerBox = new THREE.Box3(
    new THREE.Vector3(pos.x - radius, pos.y - height, pos.z - radius),
    new THREE.Vector3(pos.x + radius, pos.y + 0.1, pos.z + radius)
  );

  let pushed = new THREE.Vector3();

  for (const mesh of collidables) {
    const meshBox = new THREE.Box3().setFromObject(mesh);
    if (playerBox.intersectsBox(meshBox)) {
      const center = new THREE.Vector3();
      meshBox.getCenter(center);

      const dx = pos.x - center.x;
      const dz = pos.z - center.z;
      const overlapX = (radius + (meshBox.max.x - meshBox.min.x) / 2) - Math.abs(dx);
      const overlapZ = (radius + (meshBox.max.z - meshBox.min.z) / 2) - Math.abs(dz);

      if (overlapX < overlapZ) {
        pushed.x += Math.sign(dx) * overlapX;
      } else {
        pushed.z += Math.sign(dz) * overlapZ;
      }
    }
  }

  return pushed;
}

// ─── Main Component ────────────────────────────────────────────────────────────
export default function App() {
  const canvasRef = useRef<HTMLDivElement>(null);
  const [gameState, setGameState] = useState<"menu" | "playing" | "roundEnd">("menu");
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);
  const [scores, setScores] = useState({ alpha: 0, bravo: 0 });
  const [playerHp, setPlayerHp] = useState(100);
  const [kills, setKills] = useState(0);
  const [deaths, setDeaths] = useState(0);
  const [killFeed, setKillFeed] = useState<KillFeed[]>([]);
  const [respawning, setRespawning] = useState(false);
  const [respawnCountdown, setRespawnCountdown] = useState(0);
  const [ammo, setAmmo] = useState(30);
  const [roundWinner, setRoundWinner] = useState<Team | null>(null);
  const [locked, setLocked] = useState(false);
  const [crosshairHit, setCrosshairHit] = useState(false);

  const gameRef = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    renderer: THREE.WebGLRenderer;
    bots: BotState[];
    bullets: Bullet[];
    collidables: THREE.Mesh[];
    keys: Record<string, boolean>;
    playerVelocity: THREE.Vector3;
    playerOnGround: boolean;
    yaw: number;
    pitch: number;
    shootCooldown: number;
    playerTeam: Team;
    playerHp: number;
    playerDead: boolean;
    playerRespawnTimer: number;
    kills: number;
    deaths: number;
    scores: { alpha: number; bravo: number };
    killFeedItems: KillFeed[];
    killFeedCounter: number;
    ammo: number;
    reloading: boolean;
    reloadTimer: number;
    animFrame: number;
    active: boolean;
  } | null>(null);

  const startGame = useCallback((team: Team) => {
    setGameState("playing");
    setSelectedTeam(team);
    setScores({ alpha: 0, bravo: 0 });
    setPlayerHp(100);
    setKills(0);
    setDeaths(0);
    setKillFeed([]);
    setRespawning(false);
    setAmmo(30);
    setRoundWinner(null);
  }, []);

  useEffect(() => {
    if (gameState !== "playing" || !selectedTeam || !canvasRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x8aa8c8);
    scene.fog = new THREE.Fog(0x8aa8c8, 40, 100);

    const camera = new THREE.PerspectiveCamera(80, window.innerWidth / window.innerHeight, 0.05, 200);
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    canvasRef.current.appendChild(renderer.domElement);

    setupLighting(scene);
    const collidables = buildArena(scene);

    // Spawn player
    const spawnZ = selectedTeam === TEAM_ALPHA ? -30 : 30;
    camera.position.set(0, PLAYER_HEIGHT, spawnZ);

    // Bots
    const bots: BotState[] = [];
    for (let i = 0; i < BOT_COUNT; i++) {
      bots.push(createBot(scene, TEAM_ALPHA, i));
      bots.push(createBot(scene, TEAM_BRAVO, i + BOT_COUNT));
    }

    const bullets: Bullet[] = [];
    const keys: Record<string, boolean> = {};

    // Bullet geometry shared
    const bulletGeo = new THREE.SphereGeometry(0.06, 4, 4);
    const bulletMatAlpha = new THREE.MeshBasicMaterial({ color: 0x00e5ff });
    const bulletMatBravo = new THREE.MeshBasicMaterial({ color: 0xff4422 });

    const g = {
      scene, camera, renderer, bots, bullets, collidables, keys,
      playerVelocity: new THREE.Vector3(),
      playerOnGround: false,
      yaw: 0,
      pitch: 0,
      shootCooldown: 0,
      playerTeam: selectedTeam,
      playerHp: 100,
      playerDead: false,
      playerRespawnTimer: 0,
      kills: 0,
      deaths: 0,
      scores: { alpha: 0, bravo: 0 },
      killFeedItems: [] as KillFeed[],
      killFeedCounter: 0,
      ammo: 30,
      reloading: false,
      reloadTimer: 0,
      animFrame: 0,
      active: true,
    };
    gameRef.current = g;

    // Input
    const onKeyDown = (e: KeyboardEvent) => {
      keys[e.code] = true;
      if (e.code === "KeyR" && !g.reloading && g.ammo < 30) {
        g.reloading = true;
        g.reloadTimer = 2;
      }
    };
    const onKeyUp = (e: KeyboardEvent) => { keys[e.code] = false; };
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);

    // Pointer lock
    const canvas = renderer.domElement;
    const onClick = () => { if (!document.pointerLockElement) canvas.requestPointerLock(); };
    canvas.addEventListener("click", onClick);

    const onMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement !== canvas) return;
      g.yaw -= e.movementX * 0.002;
      g.pitch -= e.movementY * 0.002;
      g.pitch = Math.max(-Math.PI / 2.2, Math.min(Math.PI / 2.2, g.pitch));
    };
    document.addEventListener("mousemove", onMouseMove);

    const onPointerLockChange = () => {
      setLocked(document.pointerLockElement === canvas);
    };
    document.addEventListener("pointerlockchange", onPointerLockChange);

    // Shoot on click
    const onMouseDown = (e: MouseEvent) => {
      if (document.pointerLockElement !== canvas) return;
      if (e.button === 0 && g.shootCooldown <= 0 && !g.playerDead && !g.reloading && g.ammo > 0) {
        spawnPlayerBullet(g, bulletGeo, bulletMatAlpha, bulletMatBravo);
      }
    };
    document.addEventListener("mousedown", onMouseDown);

    // Resize
    const onResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener("resize", onResize);

    // Raycaster for hit detection
    const raycaster = new THREE.Raycaster();

    let lastTime = performance.now();

    function spawnPlayerBullet(
      g: typeof gameRef.current & object,
      geo: THREE.SphereGeometry,
      matA: THREE.MeshBasicMaterial,
      matB: THREE.MeshBasicMaterial
    ) {
      if (!g) return;
      g.ammo--;
      g.shootCooldown = SHOOT_COOLDOWN;
      setAmmo(g.ammo);

      const dir = new THREE.Vector3();
      g.camera.getWorldDirection(dir);

      const bmat = g.playerTeam === TEAM_ALPHA ? matA : matB;
      const bullet = new THREE.Mesh(geo, bmat);
      bullet.position.copy(g.camera.position).addScaledVector(dir, 0.5);

      g.scene.add(bullet);
      g.bullets.push({
        mesh: bullet,
        velocity: dir.multiplyScalar(BULLET_SPEED),
        team: g.playerTeam,
        fromBot: false,
        life: 2,
      });
    }

    function addKill(killer: string, victim: string, killerTeam: Team) {
      const entry: KillFeed = {
        id: g.killFeedCounter++,
        killer,
        victim,
        team: killerTeam,
        time: performance.now(),
      };
      g.killFeedItems = [entry, ...g.killFeedItems].slice(0, 6);
      setKillFeed([...g.killFeedItems]);

      if (killerTeam === TEAM_ALPHA) g.scores.alpha++;
      else g.scores.bravo++;
      setScores({ ...g.scores });

      if (g.scores.alpha >= ROUND_SCORE_LIMIT || g.scores.bravo >= ROUND_SCORE_LIMIT) {
        const winner = g.scores.alpha >= ROUND_SCORE_LIMIT ? TEAM_ALPHA : TEAM_BRAVO;
        setRoundWinner(winner);
        setGameState("roundEnd");
        g.active = false;
      }
    }

    function respawnPlayer() {
      g.playerDead = false;
      g.playerHp = 100;
      setPlayerHp(100);
      setRespawning(false);
      const sz = g.playerTeam === TEAM_ALPHA ? -30 : 30;
      g.camera.position.set((Math.random() - 0.5) * 12, PLAYER_HEIGHT, sz + (Math.random() - 0.5) * 6);
      g.playerVelocity.set(0, 0, 0);
    }

    // Main loop
    function loop() {
      if (!g.active) return;
      g.animFrame = requestAnimationFrame(loop);

      const now = performance.now();
      const dt = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;

      // ── Player movement ──
      if (!g.playerDead) {
        const forward = new THREE.Vector3(-Math.sin(g.yaw), 0, -Math.cos(g.yaw));
        const right = new THREE.Vector3(Math.cos(g.yaw), 0, -Math.sin(g.yaw));
        const move = new THREE.Vector3();

        if (keys["KeyW"]) move.addScaledVector(forward, 1);
        if (keys["KeyS"]) move.addScaledVector(forward, -1);
        if (keys["KeyA"]) move.addScaledVector(right, -1);
        if (keys["KeyD"]) move.addScaledVector(right, 1);
        if (move.lengthSq() > 0) move.normalize();

        g.playerVelocity.x = move.x * PLAYER_SPEED;
        g.playerVelocity.z = move.z * PLAYER_SPEED;

        if (keys["Space"] && g.playerOnGround) {
          g.playerVelocity.y = JUMP_FORCE;
          g.playerOnGround = false;
        }

        g.playerVelocity.y -= GRAVITY * dt;

        const newPos = g.camera.position.clone();
        newPos.x += g.playerVelocity.x * dt;
        newPos.z += g.playerVelocity.z * dt;
        newPos.y += g.playerVelocity.y * dt;

        // Ground check
        if (newPos.y < PLAYER_HEIGHT) {
          newPos.y = PLAYER_HEIGHT;
          g.playerVelocity.y = 0;
          g.playerOnGround = true;
        } else {
          g.playerOnGround = false;
        }

        // Arena bounds
        const b = ARENA_SIZE / 2 - 1;
        newPos.x = Math.max(-b, Math.min(b, newPos.x));
        newPos.z = Math.max(-b, Math.min(b, newPos.z));

        // Collision push
        const push = checkAABB(newPos, g.collidables);
        newPos.x += push.x;
        newPos.z += push.z;

        g.camera.position.copy(newPos);
        g.camera.rotation.order = "YXZ";
        g.camera.rotation.y = g.yaw;
        g.camera.rotation.x = g.pitch;

        // Cooldowns
        if (g.shootCooldown > 0) g.shootCooldown -= dt;
        if (g.reloading) {
          g.reloadTimer -= dt;
          if (g.reloadTimer <= 0) {
            g.reloading = false;
            g.ammo = 30;
            setAmmo(30);
          }
        }
        if (g.ammo <= 0 && !g.reloading) {
          g.reloading = true;
          g.reloadTimer = 2;
        }
      } else {
        // Respawn countdown
        g.playerRespawnTimer -= dt;
        setRespawnCountdown(Math.ceil(g.playerRespawnTimer));
        if (g.playerRespawnTimer <= 0) respawnPlayer();
      }

      // ── Bot AI ──
      for (const bot of g.bots) {
        if (bot.dead) {
          bot.respawnTimer -= dt;
          if (bot.respawnTimer <= 0) {
            bot.dead = false;
            bot.hp = 100;
            const sp = getBotSpawnPos(bot.team);
            bot.mesh.position.copy(sp);
            bot.mesh.visible = true;
          }
          continue;
        }

        // Find target: enemy bots or player
        let closestDist = BOT_SIGHT_RANGE;
        let targetPos: THREE.Vector3 | null = null;

        // Check player
        if (!g.playerDead && bot.team !== g.playerTeam) {
          const d = bot.mesh.position.distanceTo(g.camera.position);
          if (d < closestDist) {
            closestDist = d;
            targetPos = g.camera.position.clone();
          }
        }

        // Check enemy bots
        for (const other of g.bots) {
          if (other.dead || other.team === bot.team) continue;
          const d = bot.mesh.position.distanceTo(other.mesh.position);
          if (d < closestDist) {
            closestDist = d;
            targetPos = other.mesh.position.clone();
          }
        }

        bot.target = targetPos;
        bot.wanderTimer -= dt;

        if (targetPos) {
          // Move toward target
          const dir = new THREE.Vector3().subVectors(targetPos, bot.mesh.position).setY(0).normalize();
          bot.mesh.position.addScaledVector(dir, BOT_SPEED * dt);
          bot.mesh.lookAt(new THREE.Vector3(targetPos.x, bot.mesh.position.y, targetPos.z));

          // Shoot
          bot.shootCooldown -= dt;
          if (bot.shootCooldown <= 0 && closestDist < BOT_SHOOT_RANGE) {
            bot.shootCooldown = 0.4 + Math.random() * 0.6;
            const shootDir = dir.clone().add(new THREE.Vector3(
              (Math.random() - 0.5) * 0.1,
              (Math.random() - 0.5) * 0.05,
              (Math.random() - 0.5) * 0.1
            )).normalize();

            const bmat = bot.team === TEAM_ALPHA ? bulletMatAlpha : bulletMatBravo;
            const b = new THREE.Mesh(bulletGeo, bmat);
            b.position.copy(bot.mesh.position).setY(1.4);
            g.scene.add(b);
            g.bullets.push({
              mesh: b,
              velocity: shootDir.multiplyScalar(BULLET_SPEED * 0.7),
              team: bot.team,
              fromBot: true,
              life: 1.5,
            });
          }
        } else {
          // Wander
          if (bot.wanderTimer <= 0 || bot.mesh.position.distanceTo(bot.wanderTarget) < 1) {
            bot.wanderTimer = 3 + Math.random() * 4;
            const enemyZ = bot.team === TEAM_ALPHA ? 15 : -15;
            bot.wanderTarget.set(
              (Math.random() - 0.5) * 40,
              0,
              enemyZ + (Math.random() - 0.5) * 20
            );
          }
          const dir = new THREE.Vector3().subVectors(bot.wanderTarget, bot.mesh.position).setY(0).normalize();
          bot.mesh.position.addScaledVector(dir, BOT_SPEED * 0.6 * dt);
          bot.mesh.lookAt(new THREE.Vector3(bot.wanderTarget.x, bot.mesh.position.y, bot.wanderTarget.z));
        }

        // Ground clamp
        bot.mesh.position.y = 0;
        const bnd = ARENA_SIZE / 2 - 2;
        bot.mesh.position.x = Math.max(-bnd, Math.min(bnd, bot.mesh.position.x));
        bot.mesh.position.z = Math.max(-bnd, Math.min(bnd, bot.mesh.position.z));
      }

      // ── Bullets ──
      let hitRegistered = false;
      for (let i = g.bullets.length - 1; i >= 0; i--) {
        const b = g.bullets[i];
        b.life -= dt;
        b.mesh.position.addScaledVector(b.velocity, dt);

        if (b.life <= 0) {
          g.scene.remove(b.mesh);
          g.bullets.splice(i, 1);
          continue;
        }

        // Hit bots
        let hit = false;
        for (const bot of g.bots) {
          if (bot.dead || bot.team === b.team) continue;
          const dist = b.mesh.position.distanceTo(bot.mesh.position);
          if (dist < 1.6) {
            hit = true;
            bot.hp -= 50;
            if (bot.hp <= 0) {
              bot.dead = true;
              bot.respawnTimer = RESPAWN_TIME;
              bot.mesh.visible = false;
              const killerName = b.fromBot
                ? `Bot-${(g.bots.find(x => !x.dead && x.team === b.team)?.id ?? 0)}`
                : "You";
              const victimName = `Bot-${bot.id}`;
              if (!b.fromBot) { g.kills++; setKills(g.kills); }
              addKill(killerName, victimName, b.team);
            }
            break;
          }
        }

        // Hit player
        if (!hit && !b.fromBot === false && b.team !== g.playerTeam && !g.playerDead) {
          const dist = b.mesh.position.distanceTo(g.camera.position);
          if (dist < 0.7) {
            hit = true;
            g.playerHp -= 10;
            setPlayerHp(g.playerHp);
            hitRegistered = true;
            if (g.playerHp <= 0) {
              g.playerDead = true;
              g.playerHp = 0;
              g.deaths++;
              setDeaths(g.deaths);
              setRespawning(true);
              g.playerRespawnTimer = RESPAWN_TIME;
              const killer = `Bot-${g.bots.find(x => !x.dead && x.team !== g.playerTeam)?.id ?? "?"}`;
              addKill(killer, "You", g.playerTeam === TEAM_ALPHA ? TEAM_BRAVO : TEAM_ALPHA);
            }
          }
        }

        // Hit walls / collidables
        if (!hit) {
          raycaster.set(b.mesh.position, b.velocity.clone().normalize());
          const intersects = raycaster.intersectObjects(g.collidables);
          if (intersects.length > 0 && intersects[0].distance < 0.5) {
            hit = true;
          }
        }

        if (hit) {
          g.scene.remove(b.mesh);
          g.bullets.splice(i, 1);
        }
      }

      setCrosshairHit(hitRegistered);

      renderer.render(scene, camera);
    }

    g.animFrame = requestAnimationFrame(loop);

    return () => {
      g.active = false;
      cancelAnimationFrame(g.animFrame);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("resize", onResize);
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mousedown", onMouseDown);
      document.removeEventListener("pointerlockchange", onPointerLockChange);
      canvas.removeEventListener("click", onClick);
      if (document.pointerLockElement === canvas) document.exitPointerLock();
      renderer.dispose();
      if (canvasRef.current && canvasRef.current.contains(renderer.domElement)) {
        canvasRef.current.removeChild(renderer.domElement);
      }
    };
  }, [gameState, selectedTeam]);

  // ── Menu Screen ──────────────────────────────────────────────────────────────
  if (gameState === "menu") {
    return (
      <div className="size-full flex flex-col items-center justify-center bg-[#070a0d] relative overflow-hidden">
        {/* Background grid */}
        <div className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: "linear-gradient(rgba(0,229,255,0.4) 1px, transparent 1px), linear-gradient(90deg, rgba(0,229,255,0.4) 1px, transparent 1px)",
            backgroundSize: "40px 40px"
          }}
        />

        <div className="relative z-10 flex flex-col items-center gap-10">
          <div className="text-center">
            <div className="text-[10px] tracking-[0.5em] text-[#00e5ff] font-mono uppercase mb-3 opacity-60">
              TACTICAL ARENA — SECTOR 7
            </div>
            <h1 className="text-6xl font-bold tracking-tight uppercase" style={{ fontFamily: "Rajdhani, sans-serif", color: "#d4dde6", textShadow: "0 0 40px rgba(0,229,255,0.4)" }}>
              WARZONE
            </h1>
            <div className="text-sm font-mono text-[#5a7080] tracking-widest mt-1 uppercase">
              {BOT_COUNT}v{BOT_COUNT} Arena Combat
            </div>
          </div>

          <div className="text-[#8fa3b8] font-mono text-sm text-center">
            SELECT YOUR TEAM
          </div>

          <div className="flex gap-6">
            {/* Alpha */}
            <button
              onClick={() => startGame(TEAM_ALPHA)}
              className="group relative w-60 h-52 border border-[rgba(0,100,255,0.3)] bg-[#080e1a] overflow-hidden transition-all duration-300 hover:border-[rgba(0,229,255,0.6)] hover:shadow-[0_0_30px_rgba(0,80,255,0.3)] cursor-pointer"
            >
              <div className="absolute inset-0 bg-gradient-to-b from-[rgba(0,40,120,0.3)] to-transparent" />
              <div className="relative z-10 flex flex-col items-center justify-center h-full gap-3">
                <div className="w-16 h-16 border-2 border-[#0055ff] flex items-center justify-center bg-[rgba(0,40,120,0.5)] group-hover:border-[#00e5ff] transition-colors">
                  <div className="text-2xl font-bold text-[#4488ff] group-hover:text-[#00e5ff]" style={{ fontFamily: "Rajdhani" }}>A</div>
                </div>
                <div className="text-[#4488ff] font-bold text-xl tracking-widest group-hover:text-[#00e5ff] transition-colors" style={{ fontFamily: "Rajdhani" }}>ALPHA</div>
                <div className="text-[#2244aa] font-mono text-xs group-hover:text-[#5577cc] transition-colors">NORTH SECTOR</div>
                <div className="flex gap-1 mt-1">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="w-2 h-2 border border-[#0055ff] group-hover:border-[#00e5ff] group-hover:bg-[#00e5ff] transition-all" />
                  ))}
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#0055ff] group-hover:bg-[#00e5ff] transition-colors" />
            </button>

            <div className="flex flex-col items-center justify-center gap-2">
              <div className="w-px h-16 bg-gradient-to-b from-transparent via-[#2a3a4a] to-transparent" />
              <div className="text-[#2a3a4a] font-mono text-xs">VS</div>
              <div className="w-px h-16 bg-gradient-to-b from-[#2a3a4a] via-[#2a3a4a] to-transparent" />
            </div>

            {/* Bravo */}
            <button
              onClick={() => startGame(TEAM_BRAVO)}
              className="group relative w-60 h-52 border border-[rgba(200,30,30,0.3)] bg-[#1a0808] overflow-hidden transition-all duration-300 hover:border-[rgba(255,80,50,0.6)] hover:shadow-[0_0_30px_rgba(200,30,0,0.3)] cursor-pointer"
            >
              <div className="absolute inset-0 bg-gradient-to-b from-[rgba(120,10,10,0.3)] to-transparent" />
              <div className="relative z-10 flex flex-col items-center justify-center h-full gap-3">
                <div className="w-16 h-16 border-2 border-[#cc2222] flex items-center justify-center bg-[rgba(120,10,10,0.5)] group-hover:border-[#ff4422] transition-colors">
                  <div className="text-2xl font-bold text-[#dd4444] group-hover:text-[#ff5533]" style={{ fontFamily: "Rajdhani" }}>B</div>
                </div>
                <div className="text-[#dd4444] font-bold text-xl tracking-widest group-hover:text-[#ff5533] transition-colors" style={{ fontFamily: "Rajdhani" }}>BRAVO</div>
                <div className="text-[#882222] font-mono text-xs group-hover:text-[#bb4444] transition-colors">SOUTH SECTOR</div>
                <div className="flex gap-1 mt-1">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="w-2 h-2 border border-[#cc2222] group-hover:border-[#ff4422] group-hover:bg-[#ff4422] transition-all" />
                  ))}
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#cc2222] group-hover:bg-[#ff4422] transition-colors" />
            </button>
          </div>

          {/* Controls */}
          <div className="grid grid-cols-2 gap-x-10 gap-y-2 text-xs font-mono text-[#3a5060] border border-[rgba(0,229,255,0.06)] px-8 py-5 bg-[rgba(0,20,30,0.5)]">
            {[["WASD", "Move"], ["MOUSE", "Aim"], ["CLICK", "Shoot"], ["SPACE", "Jump"], ["R", "Reload"], ["ESC", "Menu"]].map(([k, v]) => (
              <div key={k} className="flex gap-3">
                <span className="text-[#00e5ff] opacity-60 w-14">{k}</span>
                <span>{v}</span>
              </div>
            ))}
          </div>

          <div className="text-[#2a3a4a] font-mono text-xs text-center">
            FIRST TO {ROUND_SCORE_LIMIT} KILLS WINS THE ROUND
          </div>
        </div>
      </div>
    );
  }

  // ── Round End ────────────────────────────────────────────────────────────────
  if (gameState === "roundEnd") {
    const isWinner = roundWinner === selectedTeam;
    return (
      <div className="size-full flex flex-col items-center justify-center bg-[#070a0d]">
        <div className="text-center flex flex-col items-center gap-8">
          <div className={`text-7xl font-bold tracking-wider uppercase ${isWinner ? "text-[#00e5ff]" : "text-[#ff4422]"}`}
            style={{ fontFamily: "Rajdhani", textShadow: `0 0 60px ${isWinner ? "rgba(0,229,255,0.5)" : "rgba(255,68,34,0.5)"}` }}>
            {isWinner ? "VICTORY" : "DEFEAT"}
          </div>
          <div className="text-[#5a7080] font-mono text-sm tracking-widest">
            TEAM {roundWinner?.toUpperCase()} WINS THE ROUND
          </div>
          <div className="border border-[rgba(0,229,255,0.1)] px-12 py-6 bg-[#0a0f15] font-mono text-sm space-y-2">
            <div className="flex justify-between gap-16">
              <span className="text-[#5a7080]">KILLS</span>
              <span className="text-[#d4dde6]">{kills}</span>
            </div>
            <div className="flex justify-between gap-16">
              <span className="text-[#5a7080]">DEATHS</span>
              <span className="text-[#d4dde6]">{deaths}</span>
            </div>
            <div className="flex justify-between gap-16">
              <span className="text-[#5a7080]">K/D</span>
              <span className="text-[#d4dde6]">{deaths > 0 ? (kills / deaths).toFixed(2) : kills}</span>
            </div>
            <div className="border-t border-[rgba(0,229,255,0.1)] mt-2 pt-2 flex justify-between gap-16">
              <span className="text-[#00e5ff]">ALPHA</span>
              <span className="text-[#d4dde6]">{scores.alpha}</span>
            </div>
            <div className="flex justify-between gap-16">
              <span className="text-[#ff4422]">BRAVO</span>
              <span className="text-[#d4dde6]">{scores.bravo}</span>
            </div>
          </div>
          <button
            onClick={() => setGameState("menu")}
            className="px-10 py-3 border border-[rgba(0,229,255,0.3)] text-[#00e5ff] font-mono text-sm tracking-widest hover:bg-[rgba(0,229,255,0.08)] hover:border-[rgba(0,229,255,0.6)] transition-all cursor-pointer uppercase"
          >
            Return to Menu
          </button>
        </div>
      </div>
    );
  }

  // ── In-Game HUD ──────────────────────────────────────────────────────────────
  const alphaColor = "#00aaff";
  const bravoColor = "#ff4422";
  const myColor = selectedTeam === TEAM_ALPHA ? alphaColor : bravoColor;

  return (
    <div className="size-full relative bg-black overflow-hidden">
      {/* Canvas mount */}
      <div ref={canvasRef} className="absolute inset-0" />

      {/* Pointer lock hint */}
      {!locked && !respawning && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
          <div className="border border-[rgba(0,229,255,0.3)] bg-[rgba(0,10,20,0.8)] px-8 py-4 font-mono text-sm text-[#00e5ff] tracking-widest text-center backdrop-blur-sm">
            CLICK TO LOCK MOUSE & PLAY
          </div>
        </div>
      )}

      {/* Crosshair */}
      {locked && !respawning && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30">
          <div className={`relative transition-colors ${crosshairHit ? "text-[#ff4422]" : "text-white"}`}>
            <div className="absolute w-px h-3.5 bg-current left-1/2 -translate-x-1/2 -top-4 opacity-80" />
            <div className="absolute w-px h-3.5 bg-current left-1/2 -translate-x-1/2 top-1 opacity-80" />
            <div className="absolute h-px w-3.5 bg-current top-1/2 -translate-y-1/2 -left-4 opacity-80" />
            <div className="absolute h-px w-3.5 bg-current top-1/2 -translate-y-1/2 left-1 opacity-80" />
            <div className="w-1 h-1 rounded-full bg-current opacity-50" />
          </div>
        </div>
      )}

      {/* Respawn screen */}
      {respawning && (
        <div className="absolute inset-0 flex items-center justify-center z-40 pointer-events-none">
          <div className="flex flex-col items-center gap-4">
            <div className="text-[#ff4422] font-bold text-4xl tracking-widest uppercase" style={{ fontFamily: "Rajdhani" }}>ELIMINATED</div>
            <div className="text-[#8fa3b8] font-mono text-sm">RESPAWNING IN</div>
            <div className="text-[#d4dde6] font-mono text-5xl font-bold">{respawnCountdown}</div>
          </div>
        </div>
      )}

      {/* Top scoreboard */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 z-30 pointer-events-none pt-3">
        <div className="flex items-center gap-0 font-mono text-sm">
          <div className="flex items-center gap-3 px-5 py-2 bg-[rgba(0,10,30,0.85)] border border-[rgba(0,100,255,0.3)] backdrop-blur-sm">
            <span className="text-[#00aaff] tracking-widest text-xs">ALPHA</span>
            <span className="text-white font-bold text-xl">{scores.alpha}</span>
          </div>
          <div className="px-3 py-2 bg-[rgba(0,10,20,0.9)] text-[#3a5060] text-xs border-y border-[rgba(0,229,255,0.1)]">
            / {ROUND_SCORE_LIMIT}
          </div>
          <div className="flex items-center gap-3 px-5 py-2 bg-[rgba(30,5,5,0.85)] border border-[rgba(200,30,30,0.3)] backdrop-blur-sm flex-row-reverse">
            <span className="text-[#ff4422] tracking-widest text-xs">BRAVO</span>
            <span className="text-white font-bold text-xl">{scores.bravo}</span>
          </div>
        </div>
      </div>

      {/* HP + Ammo HUD — bottom */}
      <div className="absolute bottom-6 left-6 z-30 pointer-events-none">
        <div className="flex flex-col gap-2">
          {/* Team indicator */}
          <div className="font-mono text-xs tracking-widest" style={{ color: myColor }}>
            TEAM {selectedTeam?.toUpperCase()}
          </div>
          {/* HP bar */}
          <div className="flex items-center gap-3">
            <div className="w-32 h-1.5 bg-[rgba(255,255,255,0.1)]">
              <div
                className="h-full transition-all duration-200"
                style={{ width: `${playerHp}%`, background: playerHp > 50 ? "#00dd88" : playerHp > 25 ? "#ddaa00" : "#ff3333" }}
              />
            </div>
            <span className="font-mono text-xs text-[#8fa3b8]">{playerHp} HP</span>
          </div>
          {/* K/D */}
          <div className="font-mono text-xs text-[#3a5060]">
            K <span className="text-[#d4dde6]">{kills}</span> / D <span className="text-[#d4dde6]">{deaths}</span>
          </div>
        </div>
      </div>

      {/* Ammo — bottom right */}
      <div className="absolute bottom-6 right-6 z-30 pointer-events-none text-right">
        <div className={`font-bold text-4xl ${gameRef.current?.reloading ? "text-[#ddaa00] animate-pulse" : "text-[#d4dde6]"}`}
          style={{ fontFamily: "JetBrains Mono, monospace" }}>
          {gameRef.current?.reloading ? "RELOAD" : ammo}
        </div>
        <div className="text-[#3a5060] font-mono text-xs mt-1">/ 30</div>
      </div>

      {/* Kill feed */}
      <div className="absolute top-16 right-4 z-30 pointer-events-none flex flex-col gap-1">
        {killFeed.map(k => (
          <div key={k.id} className="text-xs font-mono flex items-center gap-2 bg-[rgba(0,8,16,0.7)] px-3 py-1.5 border-l-2 backdrop-blur-sm"
            style={{ borderColor: k.team === TEAM_ALPHA ? alphaColor : bravoColor }}>
            <span style={{ color: k.killer === "You" ? "#00e5ff" : k.team === TEAM_ALPHA ? alphaColor : bravoColor }}>
              {k.killer}
            </span>
            <span className="text-[#3a5060]">›</span>
            <span style={{ color: k.victim === "You" ? "#ff4422" : "#8fa3b8" }}>
              {k.victim}
            </span>
          </div>
        ))}
      </div>

      {/* Mini compass */}
      <div className="absolute top-16 left-1/2 -translate-x-1/2 z-30 pointer-events-none">
        <div className="font-mono text-[10px] text-[#2a4050] tracking-[0.4em] select-none">
          N · · · · · · · E · · · · · · · S · · · · · · · W
        </div>
      </div>
    </div>
  );
}
