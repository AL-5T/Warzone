
  # Starter 3D game features

  This is a code bundle for Starter 3D game features. The original project is available at https://www.figma.com/design/TVrAuoatKLmxyXG6g7iCey/Starter-3D-game-features.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  